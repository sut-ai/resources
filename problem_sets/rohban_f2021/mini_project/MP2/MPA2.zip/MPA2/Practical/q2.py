def next_mrv(assignment):
    if -1 not in assignment:
        return None
    mrv = min(filter(lambda h: assignment[h] == -1, range(len(assignment))), key=lambda h: len(halls_domain[h]))
    return mrv


def is_value_consistent(assignment, hall, dept):
    return dept not in [assignment[i] for i in arcs[hall]]


def backtrack(assignment):
    hall = next_mrv(assignment)
    if hall is None:
        return assignment
    for dept in halls_domain[hall]:
        if is_value_consistent(assignment, hall, dept):
            assignment[hall] = dept
            result = backtrack(assignment)
            if result and -1 not in result:
                return result
            assignment[hall] = -1
    return None


def backtracking_search():
    return backtrack([-1 for _ in range(n)])


def ac_3():
    queue = [(i, j) for i in range(n) for j in arcs[i]]
    while queue:
        x, y = queue.pop()
        if revise(x, y):
            if not halls_domain[x]:
                return False
            queue.extend([(neighbor, x) for neighbor in arcs[x]])
    return True


def revise(x, y):
    if len(halls_domain[y]) > 1:
        return False
    revised = False
    x_revised = list()
    for value in halls_domain[x]:
        if value == halls_domain[y][0]:
            revised = True
        else:
            x_revised.append(value)
    halls_domain[x] = x_revised
    return revised


if __name__ == '__main__':
    n, m = map(int, input().split())
    halls_domain = [[] for _ in range(n)]
    arcs = [[] for _ in range(n)]

    for department in range(m):
        for hall_no in map(int, input().split()):
            halls_domain[hall_no - 1].append(department)

    edges_count = int(input())
    for _ in range(edges_count):
        edge = list(map(int, input().split()))
        arcs[edge[1] - 1].append(edge[0] - 1)
        arcs[edge[0] - 1].append(edge[1] - 1)

    if ac_3():
        solution = backtracking_search()
        print(' '.join([str(d + 1) for d in solution]) if solution else 'NO')
    else:
        print('NO')
