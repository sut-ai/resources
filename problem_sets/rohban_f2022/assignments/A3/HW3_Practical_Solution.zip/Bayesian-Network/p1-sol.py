from copy import deepcopy


def dfs(A, src, visited, n, b, paths, path):
    for i in range(n):
        if A[src][i] == 1 or A[i][src] == 1:
            if not visited[i]:
                if i == b:
                    paths.append(deepcopy(path))
                    return
                visited[i] = True
                visited_mock = deepcopy(visited)
                path.append(i)
                dfs(A, i, visited_mock, n, b, paths, path)
                path.pop()


def check_child(a, src, n, evidences, visited):
    visited[src] = True
    for i in range(n):
        if a[src][i] == 1 and not visited[i]:
            if evidences[i]:
                return True
            return check_child(a, i, n, evidences, visited)
    return False


def process(a, evidences, path, n):
    for i in range(len(path) - 2):
        node1 = path[i]
        node2 = path[i + 1]
        node3 = path[i + 2]
        if evidences[node1] or evidences[node3]:
            return
        if evidences[node2]:
            if (a[node1][node2] == 1 and a[node2][node3] == 1) or (a[node2][node1] == 1 and a[node2][node3] == 1):
                return
        else:
            if (a[node1][node2] == 1 and a[node3][node2] == 1 and not check_child(a, node2, n, evidences,
                                                                                  [False for _ in range(n)])):
                return
    mock = [x + 1 for x in path]
    print(*mock, sep=", ")
    quit()


if __name__ == '__main__':
    n, m, z = map(int, input().split())
    a = [[0 for _ in range(n)] for _ in range(n)]

    for i in range(m):
        x, y = map(int, input().split())
        a[x - 1][y - 1] = 1

    evidences = [False for _ in range(n)]
    for j in range(0, z):
        evidences[int(input()) - 1] = True

    start, end = map(int, input().split())
    start, end = start - 1, end - 1
    paths = []
    visited = [False for _ in range(n)]
    visited[start] = True
    dfs(a, start, visited, n, end, paths, [start])
    for path in paths:
        path.append(end)
        process(a, evidences, path, n)
    print('independent')
