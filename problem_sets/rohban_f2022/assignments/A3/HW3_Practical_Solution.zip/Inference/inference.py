class BN(object):
    """
    Bayesian Network implementation with sampling methods as a class
    
    Attributes
    ----------
    n: int
        number of variables
        
    G: dict
        Network representation as a dictionary. 
        {variable:[[children],[parents]]} # You can represent the network in other ways. This is only a suggestion.
    """
    
    def __init__(self, graph, CPT) -> None:
        ############################################################
        # Initialzie Bayesian Network                              #
        ############################################################
        self.n = len(graph)
        self.G = graph
        self.set_topological_order()
        self.CPT = CPT
    
    def cpt(self, node, parents_value) -> dict:
        """
        This is a function that returns cpt of the given node
        
        Parameters
        ----------
        node:
            a variable in the bayes' net
            
        Returns
        -------
        result: dict
            {parents_value1: {node_value1:p_value1, node_value2:p_value2, ...}, parents_value2: ...}
        """
        return self.CPT[node][parents_value]
    
    def pmf(self, query, evidence) -> float:
        """
        This function gets a variable and its value as query and a list of evidences and returns probability mass function P(Q=q|E=e)
        
        Parameters
        ----------
        query:
            a variable and its value
            e.g. {'A': 1}
        evidence:
            list of variables and their values
            e.g. {'B': 0, 'C': 1}
        
        Returns
        -------
        PMF: float
            P(query|evidence)
        """
        hidden_variables = [var for var in self.G if var not in query and var not in evidence]
        factors = [[[var, *self.G[var][1]], CPT.copy()] for var, CPT in self.CPT.items()]
        self.remove_nonmatching_evidences(evidence, factors)
        for var in hidden_variables:
            self.join_and_eliminate(var, factors, evidence)
        joint_factor = self.get_join_all_factors(factors, query, evidence)
        self.normalize(joint_factor)
        row = ''.join([str(query[variable] if variable in query else evidence[variable]) for variable in joint_factor[0]])
        return joint_factor[1][row]
        
    
    def sampling(self, query, evidence, sampling_method, num_iter, num_burnin = 1e2) -> float:
        """
        Parameters
        ----------
        query: list
            list of variables an their values
            e.g. {'A': 0, 'E': 1}
        evidence: list
            list of observed variables and their values
            e.g. {'B': 0, 'C': 1}
        sampling_method:
            "Prior", "Rejection", "Likelihood Weighting", "Gibbs"
        num_iter:
            number of the generated samples 
        num_burnin:
            (used only in gibbs sampling) number of samples that we ignore at the start for gibbs method to converge
            
        Returns
        -------
        probability: float
            approximate P(query|evidence) calculated by sampling
        """
        ############################################################
        #     Prior sampling                                       #
        #     Rejection sampling                                   #
        #     Likelihood weighting                                 #
        #     Gibbs sampling                                       #
        ############################################################
        if sampling_method == 'Prior':
            return self.prior_sample(query, evidence, num_iter)
        elif sampling_method == 'Rejection':
            return self.rejection_sample(query, evidence, num_iter)
        elif sampling_method == 'Likelihood Weighting':
            return self.likelihood_sample(query, evidence, num_iter)
        elif sampling_method == 'Gibbs':
            return self.gibbs_sample(query, evidence, num_iter, num_burnin)
        
        
    def prior_sample(self, query, evidence, num_iter):
        count_consistent_evidence = 0
        count_consistent_query = 0
        for _ in range(num_iter):
            sample = self.get_prior_sample()
            if self.sample_consistent_with_evidence(sample, evidence):
                count_consistent_evidence += 1
                if self.sample_consistent_with_query(sample, query):
                    count_consistent_query += 1
        return count_consistent_query / count_consistent_evidence
        
        
    def sample_consistent_with_evidence(self, sample, evidence):
        for var, value in evidence.items():
            if value != sample[var]:
                return False
        return True
    
    
    def sample_consistent_with_query(self, sample, query):
        for var, value in query.items():
            if value != sample[var]:
                return False
        return True
        
        
    def get_prior_sample(self):
        sample = {}
        for var in self.topological_order:
            row = '0' + ''.join([str(sample[parent]) for parent in self.G[var][1]])
            sample[var] = 0 if random.uniform(0, 1) < self.CPT[var][row] else 1
        return sample
    
    
    def rejection_sample(self, query, evidence, num_iter):
        count_consistent_query = 0
        for _ in range(num_iter):
            sample = self.get_rejection_sample(evidence)
            if self.sample_consistent_with_query(sample, query):
                count_consistent_query += 1
        return count_consistent_query / num_iter
    
    
    def get_rejection_sample(self, evidence):
        sample = self.get_prior_sample()
        while not self.sample_consistent_with_evidence(sample, evidence):
            sample = self.get_prior_sample()
        return sample
    
    
    def likelihood_sample(self, query, evidence, num_iter):
        all_weight = 0
        consistent_query_weight = 0
        for _ in range(num_iter):
            sample, weight = self.get_likelihood_sample(evidence)
            all_weight += weight
            if self.sample_consistent_with_query(sample, query):
                consistent_query_weight += weight
        return consistent_query_weight / all_weight
    
    
    def get_likelihood_sample(self, evidence):
        sample = evidence.copy()
        weight = 1
        for var in self.topological_order:
            parents_values = ''.join([str(sample[parent]) for parent in self.G[var][1]])
            if var in evidence:
                row = str(evidence[var]) + parents_values
                weight *= self.CPT[var][row]
            else:
                row = '0' + parents_values
                sample[var] = 0 if random.uniform(0, 1) < self.CPT[var][row] else 1
        return sample, weight
            
        
    def gibbs_sample(self, query, evidence, num_iter, num_burnin):
        count_consistent_query = 0
        nonevidence_vars = [var for var in self.G if var not in evidence]
        for i in range(num_iter+int(num_burnin)):
            chosen_var = nonevidence_vars[i % len(nonevidence_vars)]
            if i == 0:
                sample = self.get_randomly_sample(evidence)
            else:
                self.set_gibbs_sample(chosen_var, sample) 
            if i >= num_burnin and self.sample_consistent_with_query(sample, query):
                count_consistent_query += 1
        return count_consistent_query / num_iter
    
    
    def get_randomly_sample(self, evidence):
        return {**{var: random.choice([0, 1]) for var in self.G if var not in evidence}, **evidence}
            
                
    def set_gibbs_sample(self, chosen_var, sample):
        del sample[chosen_var]
        sample[chosen_var] = 0 if random.uniform(0, 1) < self.pmf({chosen_var: 0}, sample) else 1
        
    
    def set_topological_order(self):
        self.topological_order = []
        visited = {node: False for node in self.G}
        for node, neighbors in self.G.items():
            if len(neighbors[1]) == 0:
                self.topological_sort(node, visited)
    
    
    def topological_sort(self, node, visited):
        visited[node] = True
        self.topological_order.append(node)
        for child in self.G[node][0]:
            if not visited[child] and self.all_parents_visited(child, visited):
                self.topological_sort(child, visited)
             
            
    def all_parents_visited(self, node, visited) -> bool:
        for parent in self.G[node][1]:
            if not visited[parent]:
                return False
        return True
           
        
    def remove_nonmatching_evidences(self, evidence, factors):
        for var, value in evidence.items():
            for factor in factors:
                if var in factor[0]:
                    index_var = factor[0].index(var)
                    rows_to_remove = [values for values in factor[1] if values[index_var] != str(value)]
                    for row in rows_to_remove:
                        del factor[1][row]
               
            
    def join_and_eliminate(self, var, factors, evidence):
        var_factors = self.get_var_factors(var, factors)
        joined_factor = self.get_joined_factor(var_factors, var, evidence)
        factors.append(joined_factor)
        
        
    def get_joined_factor(self, var_factors, var, evidence):
        variables_in_joined_factor = self.get_variables_in_joined_factor(var_factors, var, evidence)
        evidence_values = ''.join([str(evidence[variable]) for variable in variables_in_joined_factor[1]])
        prob_table_joined_factor = {}
        for i in range(2**len(variables_in_joined_factor[0])):
            if len(variables_in_joined_factor[0]) != 0:
                binary_values = '{:b}'.format(i)
                values = '0' * (len(variables_in_joined_factor[0]) - len(binary_values)) + binary_values
            else:
                values = ''
            probability0 = 1
            probability1 = 1
            for factor in var_factors:
                row0, row1 = self.get_rows_factor(factor, var, evidence, values, variables_in_joined_factor)
                probability0 *= factor[1][row0] 
                probability1 *= factor[1][row1]
            probability = probability0 + probability1
            row = values + evidence_values
            prob_table_joined_factor[row] = probability
        return [[*variables_in_joined_factor[0], *variables_in_joined_factor[1]], prob_table_joined_factor]
    
    
    def get_rows_factor(self, factor, var, evidence, values, variables_in_joined_factor):
        row0 = ''
        row1 = ''
        for variable in factor[0]:
            if variable == var:
                row0 += '0'
                row1 += '1'
            elif variable in evidence:
                row0 += str(evidence[variable])
                row1 += str(evidence[variable])
            else:
                row0 += values[variables_in_joined_factor[0].index(variable)]
                row1 += values[variables_in_joined_factor[0].index(variable)]
        return row0, row1
    
        
    def get_var_factors(self, var, factors):
        var_factors = []
        for factor in factors.copy():
            if var in factor[0]:
                var_factors.append(factor)
                factors.remove(factor)
        return var_factors
             
        
    def get_variables_in_joined_factor(self, var_factors, var, evidence):
        factors_variables = []
        for factor in var_factors:
            factors_variables += factor[0]
        factors_variables = list(set(factors_variables)-{var})
        evidence_variables_in_joined_factor = []
        nonevidence_variables_in_joined_factor = []
        for variable in factors_variables:
            if variable in evidence:
                evidence_variables_in_joined_factor.append(variable)
            else:
                nonevidence_variables_in_joined_factor.append(variable)
        return [nonevidence_variables_in_joined_factor, evidence_variables_in_joined_factor]
    
    
    def get_join_all_factors(self, factors, query, evidence):
        prob_table_joined_factor = {}
        query_vars = list(query.keys())
        evidence_vars = list(evidence.keys())
        evidence_values = ''.join([str(evidence[variable]) for variable in evidence_vars])
        for i in range(2**len(query)):
            binary_values = '{:b}'.format(i)
            values = '0' * (len(query) - len(binary_values)) + binary_values
            probability = 1
            for factor in factors:
                factor_row = self.get_row_factor(factor, query_vars, evidence, values)
                probability *= factor[1][factor_row] 
            row = values + evidence_values
            prob_table_joined_factor[row] = probability
        return [[*query_vars, *evidence_vars], prob_table_joined_factor]
    
    
    def get_row_factor(self, factor, query_vars, evidence, values):
        row = ''
        for variable in factor[0]:
            if variable in evidence:
                row += str(evidence[variable])
            else:
                row += values[query_vars.index(variable)]
        return row
    
    
    def normalize(self, joint_factor):
        sum = 0
        for probability in list(joint_factor[1].values()):
            sum += probability
        if sum == 0:
            return
        for row in joint_factor[1]:
            joint_factor[1][row] /= sum
            