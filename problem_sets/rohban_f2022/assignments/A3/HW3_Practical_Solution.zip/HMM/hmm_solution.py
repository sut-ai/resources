import numpy as np
from itertools import product
import sys


if __name__ == '__main__':
    sys.stdin = open('input.txt', 'r')
    k = int(input())
    n = int(input())
    m = int(input())
    observed = [int(x) for x in input().split()]
    S = [float(x) for x in input().split()]
    # print(observed)
    # print(S)
    H = []
    for i in range(n):
        H_i = [float(x) for x in input().split()]
        H.append(H_i)
    M = []
    for i in range(n):
        M_i = [float(x) for x in input().split()]
        M.append(M_i)
    # print(k, n, m)
    # print(S)
    # print(H)
    # print(M)
    states = [i for i in range(n)]
    all_states = list(product(states, repeat=k))
    mx = -1
    res_state = []
    for state in all_states:
        ans = 1
        ans *= S[state[0]]
        # print(S[state[0]], end=" ")
        for i in range(1, k):
            ans *= H[state[i-1]][state[i]]
            # print(H[state[i - 1]][state[i]], end= " ")
        for i, data in enumerate(observed):
            ans *= M[state[i]][data - 1]
        #     print(M[state[i]][data - 1], end=" ")
        # print(state, ans)
        if ans > mx:
            mx = ans
            res_state = state
    # print(mx, res_state)
    # print(M[res_state[k - 1]])
    x,y = max(enumerate(M[res_state[k - 1]]), key= lambda x: x[1])
    # print(res_state)
    print(x + 1, round(y, 2))
    exit(0)

    b = a/a.sum(axis=0,keepdims=1)
    for i in range(5):
        s = sum(a[i])
        for j in range(7):
            a[i][j] /= s
            a[i][j] = round(a[i][j], 2)
            print(a[i][j], end=" ")
        print()
