Inference
