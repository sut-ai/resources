from typing import Tuple
import numpy as np
import pandas as pd
from tqdm import tqdm


class Genetic:

    """
    NOTE:
        - S is the set of members.
        - T is the target value.
        - Chromosomes are represented as an array of 0 and 1 with the same length as the set.
        (0 means the member is not included in the subset, 1 means the member is included in the subset)

        Feel free to add any other function you need.
    """

    def __init__(self):
        pass

    def generate_initial_population(self, n: int, k: int) -> np.ndarray:
        """
        Generate initial population: This function is used to generate the initial population.

        Inputs:
        - n: number of chromosomes in the population
        - k: number of genes in each chromosome

        It must generate a population of size n for a set of k members.

        Outputs:
        - initial population
        """

        return np.random.randint(low=0, high=2, size=(n, k))

    def objective_function(self, chromosome: np.ndarray, S: np.ndarray) -> int:
        """
        Objective function: This function is used to calculate the sum of the chromosome.

        Inputs:
        - chromosome: chromosome to be evaluated
        - S: set of members

        It must calculate the sum of the members included in the subset (i.e. sum of S[i]s where Chromosome[i] == 1).

        Outputs: sum of the chromosome
        """

        return np.dot(S, chromosome)

    def is_feasible(self, chromosome: np.ndarray, S: np.ndarray, T: int) -> bool:
        """
        This function is used to check if the sum of the chromosome (objective function) is equal or less to the target value.

        Inputs:
        - chromosome: chromosome to be evaluated
        - S: set of members
        - T: target value

        Outputs: True (1) if the sum of the chromosome is equal or less to the target value, False (0) otherwise
        """

        return self.objective_function(chromosome, S) <= T

    def cost_function(self, chromosome: np.ndarray, S: np.ndarray, T: int) -> int:
        """
        Cost function: This function is used to calculate the cost of the chromosome.

        Inputs:
        - chromosome: chromosome to be evaluated
        - S: set of members
        - T: target value

        The cost is calculated in this way:
        - if the chromosome is feasible, the cost is equal to (target value - sum of the chromosome)
        - if the chromosome is not feasible, the cost is equal to the sum of the chromosome

        Outputs: cost of the chromosome
        """

        s = float(self.is_feasible(chromosome, S, T))
        objective = self.objective_function(chromosome, S)
        return s * (T - objective) + (1 - s) * objective

    def selection(self, population: np.ndarray, S: np.ndarray, T: int) -> Tuple[np.ndarray, np.ndarray]:
        """
        Selection: This function is used to select the best chromosome from the population.

        Inputs:
        - population: current population
        - S: set of members
        - T: target value

        It select the best chromosomes in this way:
        - it gets 4 random chromosomes from the population
        - it calculates the cost of each selected chromosome
        - it selects the chromosome with the lowest cost from the first two selected chromosomes
        - it selects the chromosome with the lowest cost from the last two selected chromosomes
        - it returns the selected chromosomes from two previous steps

        Outputs: two best chromosomes with the lowest cost out of four selected chromosomes
        """

        indices = np.random.randint(low=0, high=len(population), size=4)
        selected_chromosomes = population[indices, :]
        cost_selected_chromosomes = [self.cost_function(
            chromosome, S, T) for chromosome in selected_chromosomes]
        winner_1 = selected_chromosomes[np.argmin(
            cost_selected_chromosomes[:2])]
        winner_2 = selected_chromosomes[np.argmin(
            cost_selected_chromosomes[2:]) + 2]
        return winner_1, winner_2

    def crossover(self, parent1: np.ndarray, parent2: np.ndarray, S: np.ndarray, prob: float = 0.5) -> Tuple[np.ndarray, np.ndarray]:
        """
        Crossover: This function is used to create two new chromosomes from two parents.

        Inputs:
        - parent1: first parent chromosome
        - parent2: second parent chromosome


        It creates two new chromosomes in this way:
        - it gets a random number between 0 and 1
        - if the random number is less than the crossover probability, it performs the crossover, otherwise it returns the parents
        - Crossover steps:
        -   it gets a random number between 0 and the length of the parents
        -   it creates two new chromosomes by swapping the first part of the first parent with the first part of the second parent and vice versa
        -   it returns the two new chromosomes as children


        Outputs: two children chromosomes
        """

        r = np.random.random()
        if r <= prob:
            index = np.random.randint(len(S))
            child1 = parent1[:index + 1]
            child1 = np.append(child1, parent2[index + 1:])
            child2 = parent2[:index + 1]
            child2 = np.append(child2, parent1[index + 1:])
            return child1, child2
        else:
            return parent1, parent2

    def mutation(self, child1: np.ndarray, child2: np.ndarray, prob: float = 0.01) -> Tuple[np.ndarray, np.ndarray]:
        """
        Mutation: This function is used to mutate the child chromosomes.

        Inputs:
        - child1: first child chromosome
        - child2: second child chromosome
        - prob: mutation probability

        It mutates the child chromosomes in this way:
        - it gets a random number between 0 and 1
        - if the random number is less than the mutation probability, it performs the mutation, otherwise it returns the children
        - Mutation steps:
        -   it gets a random number between 0 and the length of the children
        -   it mutates the first child by swapping the value of the random index of the first child
        -   it mutates the second child by swapping the value of the random index of the second child
        -   it returns the two mutated children

        Outputs: two mutated children chromosomes
        """

        r = np.random.random()
        if r <= prob:
            index_1 = np.random.randint(len(child1))
            child1[index_1] = 1 - child1[index_1]
            index_2 = np.random.randint(len(child2))
            child2[index_2] = 1 - child2[index_2]
        return child1, child2

    def run_algorithm(self, S: np.ndarray, T: int, crossover_probability: float = 0.5, mutation_probability: float = 0.1, population_size: int = 100, num_generations: int = 100):
        """
        Run algorithm: This function is used to run the genetic algorithm.

        Inputs:
        - S: array of integers
        - T: target value

        It runs the genetic algorithm in this way:
        - it generates the initial population
        - it iterates for the number of generations
        - for each generation, it makes a new empty population
        -   while the size of the new population is less than the initial population size do the following:
        -       it selects the best chromosomes(parents) from the population
        -       it performs the crossover on the best chromosomes
        -       it performs the mutation on the children chromosomes
        -       if the children chromosomes have a lower cost than the parents, add them to the new population, otherwise add the parents to the new population
        -   update the best cost if the best chromosome in the population has a lower cost than the current best cost
        -   update the best solution if the best chromosome in the population has a lower cost than the current best solution
        -   append the current best cost and current best solution to the records list
        -   update the population with the new population
        - return the best cost, best solution and records


        Outputs: the best cost, best solution and records.
        """

        # UPDATE THESE VARIABLES (best_cost, best_solution, records)
        best_cost = np.Inf
        best_solution = None
        records = []

        population = self.generate_initial_population(population_size, len(S))
        cost_list = [self.cost_function(i, S, T) for i in population]

        for i in tqdm(range(num_generations)):
            new_population = []
            while len(new_population) < population_size:
                parent1, parent2 = self.selection(population, S, T)
                child1, child2 = self.crossover(
                    parent1, parent2, S, crossover_probability)
                child1, child2 = self.mutation(
                    child1, child2, mutation_probability)
                if self.cost_function(child1, S, T) < self.cost_function(parent1, S, T):
                    new_population.append(child1)
                else:
                    new_population.append(parent1)
                if self.cost_function(child2, S, T) < self.cost_function(parent2, S, T):
                    new_population.append(child2)
                else:
                    new_population.append(parent2)
                # if self.cost_function(child1, S, T) < self.cost_function(parent1, S, T) and self.is_feasible(child1, S, T):
                #     new_population.append(child1)
                # elif self.is_feasible(parent1, S, T):
                #     new_population.append(parent1)
                # if self.cost_function(child2, S, T) < self.cost_function(parent2, S, T) and self.is_feasible(child2, S, T):
                #     new_population.append(child2)
                # elif self.is_feasible(parent2, S, T):
                #     new_population.append(parent2)
            cost_list = [self.cost_function(i, S, T) for i in new_population]
            temp_cost = min(cost_list)
            temp_solution = population[cost_list.index(temp_cost)]
            if temp_cost < best_cost or best_solution is None:
                best_solution = temp_solution
                best_cost = temp_cost
            population = np.array(new_population)
            records.append({'iteration': i, 'best_cost': best_cost,
                           'best_solution': best_solution})  # DO NOT REMOVE THIS LINE

        records = pd.DataFrame(records)  # DO NOT REMOVE THIS LINE

        return best_cost, best_solution, records
