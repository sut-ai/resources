#include <bits/stdc++.h>
using namespace std;

int N;
int M;

vector<int> neighbors[20];

size_t dist[20][20];

class State
{
public:
    State(const vector<int> &positions)
    {
        this->positions = positions;
        update_hole();
        estimate = 0;
        passed = 0;
        get_estimate();
    }

    bool is_final() const
    {
        for (int idx = 0; idx < N; ++idx)
            if (idx != positions[idx])
                return false;

        return true;
    }

    bool operator<(const State &other) const
    {
        return -(passed + estimate) < -(other.passed + other.estimate);
    }

    std::size_t hash() const
    {
        std::size_t seed = positions.size();
        for (auto x : positions)
        {
            x = ((x >> 16) ^ x) * 0x45d9f3b * 0x45d9f3b;
            x = ((x >> 16) ^ x) * 0x45d9f3b;
            x = (x >> 16) ^ x;
            seed ^= x + 0x9e3779b9 + (seed << 6) + (seed >> 2);
        }
        return seed;
    }

    size_t distance()
    {
        return passed;
    }

    vector<State> get_neighbors()
    {
        vector<State> result;
        for (auto neighbor : neighbors[hole_pos])
        {
            State clone = *this;
            swap(clone.positions[hole_pos], clone.positions[neighbor]);
            clone.update_hole();
            clone.passed += 1;
            clone.estimate = 0;
            clone.get_estimate();
            result.push_back(clone);
        }

        return result;
    }

    size_t get_estimate()
    {
        if (estimate == 0)
        {
            for (int i = 0; i < N; i++)
                if (i != hole_pos)
                    estimate += dist[i][positions[i]];
        }

        return estimate;
    }

    string get_string()
    {
        string result = "";
        result += to_string(passed) + ":" + to_string(passed + estimate) + '\t';
        for (auto pos : positions)
            result += to_string(pos) + '\t';
        return result;
    }

private:
    void update_hole()
    {
        hole_pos = find(positions.begin(), positions.end(), 0) - positions.begin();
    }

    vector<int> positions;
    size_t hole_pos;
    size_t passed;
    size_t estimate;
};

void fill_dist()
{
    for (int i = 0; i < N; i++)
        for (int j = 0; j < N; j++)
        {
            if (find(neighbors[i].begin(), neighbors[i].end(), j) != neighbors[i].end())
                dist[i][j] = 1;
            else
                dist[i][j] = (i == j ? 0 : SIZE_MAX / 3);
        }

    for (int i = 0; i < N; i++)
        for (int j = 0; j < N; j++)
            for (int k = 0; k < N; k++)
                dist[i][j] = min(dist[i][k] + dist[k][j], dist[i][j]);
}

int solve_astar(const State &initial)
{
    priority_queue<State> queue;
    unordered_map<size_t, size_t> weight;
    queue.push(initial);

    size_t cnt = 0;

    while (queue.size() > 0)
    {
        cnt += 1;
        if (cnt > 1e6)
            return -1;

        State current = queue.top();
        queue.pop();

        if (current.is_final())
            return current.distance();

        for (State state : current.get_neighbors())
        {
            if (weight.find(state.hash()) == weight.end() || state.distance() < weight[state.hash()])
            {
                queue.push(state);
                weight[state.hash()] = state.distance();
            }
        }
    }

    return -1;
}

int main()
{
    cin >> N >> M;
    for (int i = 0; i < M; i++)
    {
        size_t u, v;
        cin >> u >> v;
        neighbors[u].push_back(v);
        neighbors[v].push_back(u);
    }

    vector<int> positions;
    for (int i = 0; i < N; i++)
    {
        int l;
        cin >> l;
        positions.push_back(l);
    }

    fill_dist();
    State initial = State(positions);
    cout << solve_astar(initial) << endl;
}
