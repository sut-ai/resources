from math import inf
from heapq import *


test_no = int(input())
for test in range(test_no):

    # get city & road number
    line = [int(num) for num in input().split()]
    city_no = line[0]
    road_no = line[1]

    # set state graphs
    adj = []
    ex_adj = []
    for i in range(city_no):
        adj.append([])
        ex_adj.append([])
        ex_adj.append([])

    # fill state graphs
    for i in range(road_no):
        line = [int(num) for num in input().split()]
        src = line[0] - 1
        dest = line[1] - 1
        dist = line[2]

        adj[src].append((dest, dist))
        adj[dest].append((src, dist))

        ex_adj[src].append((dest, dist))
        ex_adj[dest].append((src, dist))

        ex_adj[src + city_no].append((dest + city_no, dist / 2))
        ex_adj[dest + city_no].append((src + city_no, dist / 2))

    # set terrorists
    terrorist_no = int(input())
    terrorist_city = [int(num) - 1 for num in input().split()]

    # set cars
    car_no = int(input())
    car_city = [int(num) - 1 for num in input().split()]

    # set car cities in terrorist graph
    for city in car_city:
        ex_adj[city].append((city + city_no, 0))
        ex_adj[city + city_no].append((city, 0))

    # set source & destination
    line = input().split()
    source = int(line[0]) - 1
    destination = int(line[1]) - 1

    # set destination in terrorist graph
    ex_adj[destination].append((destination + city_no, 0))
    ex_adj[destination + city_no].append((destination, 0))

    # search for Tintin
    tintin = 0
    cost = [inf] * city_no
    father = [-1] * city_no
    visit = [False] * city_no
    cost[source] = 0
    heap = [(0, source)]

    while True:
        current_cost, current_node = heappop(heap)
        visit[current_node] = True
        if current_cost > cost[current_node]:
            continue
        for neighbor in adj[current_node]:
            neighbor_index, edge_weight = neighbor
            if visit[neighbor_index]:
                continue
            new_cost = cost[current_node] + edge_weight
            if cost[neighbor_index] > new_cost:
                cost[neighbor_index] = new_cost
                heappush(heap, (cost[neighbor_index], neighbor_index))
                father[neighbor_index] = current_node

        if current_node == destination:
            tintin = cost[current_node]
            break

    # search for terrorists
    terrorist = 0
    cost = [inf] * (2 * city_no)
    visit = [False] * (2 * city_no)
    cost[destination] = 0
    heap = [(0, destination)]

    while True:
        current_cost, current_node = heappop(heap)
        visit[current_node] = True
        if current_cost > cost[current_node]:
            continue
        for neighbor in ex_adj[current_node]:
            neighbor_index, edge_weight = neighbor
            if visit[neighbor_index]:
                continue
            new_cost = cost[current_node] + edge_weight
            if cost[neighbor_index] > new_cost:
                cost[neighbor_index] = new_cost
                heappush(heap, (cost[neighbor_index], neighbor_index))

        if current_node in terrorist_city:
            terrorist = cost[current_node]
            break

    # print answer
    if tintin > terrorist:
        print('Poor Tintin')

    else:
        path = []
        path_node = destination
        while path_node != -1:
            path.append(path_node + 1)
            path_node = father[path_node]

        print(tintin)
        print(len(path))
        print(' '.join(str(x) for x in path[::-1]))
