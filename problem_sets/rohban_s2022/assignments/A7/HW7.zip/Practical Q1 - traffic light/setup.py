from setuptools import setup

setup(name='gym_cityflow', # name of the package, used like this: `import gym_cityflow`
      version='0.1',
      install_requires=['gym', 'cityflow'] # And any other dependencies required
)
