from collections import defaultdict, deque
 
n, m, k = map(int, input().split())
graph = defaultdict(list)
# making the graph from input using a dictionary
for i in range(m):
    x, y = map(int, input().split())
    graph[x].append(y)
    graph[y].append(x)

# forbidden paths
mp = {} 
for i in range(k):
    a, b, c = map(int, input().split())
    mp[(a, b, c)] = 1


q = deque() # queue used for search algorithm
q.append([1, [-1]])
res = [-1] # result path
vis = {} # visited
while q:
    node, path = q.popleft()
    if node == n: # if got to the destination, break from loop.
        res = path[1:] + [node]
        break
    for i in graph[node]:
        if (node, i) not in vis:
            # check if path is not forbidden
            if (path[-1], node, i) not in mp:
                q.append([i, path + [node]])
                vis[(node, i)] = 1

#output
if len(res) > 1:
    print(len(res) - 1)
else:
    print(-1)