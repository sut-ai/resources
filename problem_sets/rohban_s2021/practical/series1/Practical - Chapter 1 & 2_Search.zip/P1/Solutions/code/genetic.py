import re
import random
from matplotlib import pyplot as plt

# %%
f = open("input1.txt", "r")
dna_len = int(f.readline())
population_size = int(f.readline())
TIME_LIMIT = int(f.readline())
nucleotides = f.readline().split()
constraints = [line.split() for line in f.readlines()]
constraints = [(line[0], int(line[1])) for line in constraints]
# %%
mutation_size = dna_len // 100
# mutation_size = 1
print("MUTATION_SIZE:", mutation_size)
population = [''.join(random.choices(nucleotides, k=dna_len)) for i in range(population_size)]


# %%
def calculate_fitness(generation):
    generation_fitness = []
    for dna in generation:
        fitness = 0
        for constraint in constraints:
            fitness += len(re.findall(constraint[0], dna)) * constraint[1]
        generation_fitness.append(fitness)
    return generation_fitness


def select(generation, generation_fitness):
    bias = max(-1.1 * min(generation_fitness), 1)
    generation_fitness = [fitness + bias for fitness in generation_fitness]
    selected_parents = random.choices(population=generation, weights=generation_fitness, k=dna_len)
    return selected_parents


def cross_over(selected_parents):
    children = []
    for i in range(population_size // 2):
        cutoff = random.randint(0, dna_len)
        children.append(selected_parents[2 * i][0:cutoff] + selected_parents[2 * i + 1][cutoff:dna_len])
        children.append(selected_parents[2 * i + 1][0:cutoff] + selected_parents[2 * i][cutoff:dna_len])
    return children


def mutate(children, p):
    for i in range(population_size):
        if random.random() < p:
            for j in range(mutation_size):
                temp = list(children[i])
                temp[random.randint(0, dna_len - 1)] = random.choice(nucleotides)
                children[i] = ''.join(temp)
    return children


# %%
fitness_list = []
for t in range(TIME_LIMIT):
    population_fitness = calculate_fitness(population)
    fitness_list.append(max(population_fitness))
    population = mutate(cross_over(select(population, population_fitness)), 0.01)
# %%
plt.plot(fitness_list)
plt.show()
