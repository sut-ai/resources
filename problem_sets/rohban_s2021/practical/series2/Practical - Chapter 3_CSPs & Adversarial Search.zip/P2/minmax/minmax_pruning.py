from utils import *
import math


def get_chooser(depth):
    def temp(this_game_map: np.ndarray):
        return choose(this_game_map, depth)

    return temp


def choose(this_game_map: np.ndarray, depth):
    return best_choice

