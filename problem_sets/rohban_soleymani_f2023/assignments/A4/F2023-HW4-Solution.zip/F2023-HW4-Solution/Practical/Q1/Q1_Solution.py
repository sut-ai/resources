import networkx as nx

n = int(input())
m = int(input())

temp = []
for _ in range(m):
    u, v = map(int, input().split('->'))
    temp.append((u, v))

tree = nx.DiGraph(temp)
T = int(input())
for _ in range(T):
    first = int(input())
    second = int(input())
    obs = {int(i) for i in input().split()}
    print(nx.d_separated(tree, {first}, {second}, obs))